#ifndef _HOUSE_H
#define _HOUSE_H

namespace House {
   extern int nVerts;
   extern double vertices[];
   extern double colors[];
   extern int indices[];
}

#endif